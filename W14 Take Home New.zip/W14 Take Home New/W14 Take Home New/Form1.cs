﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace W14_Take_Home_New
{
    public partial class Form_InsertMatch : Form
    {
        public Form_InsertMatch()
        {
            InitializeComponent();
        }

        DataTable dtsimpanID = new DataTable();
       
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        string sqlQuery;
        DataTable dtsimpanPremierLeague = new DataTable();
        DataTable dtTeamHome = new DataTable();
        DataTable dtTeamAway = new DataTable();
        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtPremierLeague = new DataTable();
        string tanggal;
        string teamhome;
        string teamaway;

        private void Form_InsertMatch_Load(object sender, EventArgs e)
        {
            cbx_TeamHome.SelectedIndexChanged -= cbx_TeamHome_SelectedIndexChanged;
            cbx_TeamAway.SelectedIndexChanged -= cbx_TeamAway_SelectedIndexChanged;

            sqlConnect = new MySqlConnection("server=localhost; uid=root; password=110505*; database=premier_league");
            dtTeamHome = new DataTable();
            dtTeamAway = new DataTable();
            sqlQuery = "SELECT team_id, team_name from team";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamHome);
            sqlDataAdapter.Fill(dtTeamAway);

            cbx_TeamHome.ValueMember = "team_id";
            cbx_TeamHome.DisplayMember = "team_name";
            cbx_TeamHome.DataSource = dtTeamHome;

            cbx_TeamAway.ValueMember = "team_id";
            cbx_TeamAway.DisplayMember = "team_name";
            cbx_TeamAway.DataSource = dtTeamAway;


            cbx_TeamHome.SelectedIndexChanged += cbx_TeamHome_SelectedIndexChanged;
            cbx_TeamAway.SelectedIndexChanged += cbx_TeamAway_SelectedIndexChanged;
            cbx_TeamHome.SelectedIndex = -1;
            cbx_TeamAway.SelectedIndex = -1;

            //cbx_TeamHome.Text = string.Empty;
            //cbx_TeamAway.Text = string.Empty;

            cbx_Type.Items.Add("GO");
            cbx_Type.Items.Add("GP");
            cbx_Type.Items.Add("GW");
            cbx_Type.Items.Add("CR");
            cbx_Type.Items.Add("CY");
            cbx_Type.Items.Add("PM");

            dtPremierLeague.Columns.Add("Team");
            dtPremierLeague.Columns.Add("Player");
            dtPremierLeague.Columns.Add("Type");

            dtsimpanID.Columns.Add("match id");
            dtsimpanID.Columns.Add("minute");
            dtsimpanID.Columns.Add("team id");
            dtsimpanID.Columns.Add("player id");
            dtsimpanID.Columns.Add("type");
            dtsimpanID.Columns.Add("delete");

        }

        private void cbx_TeamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbx_TeamHome.SelectedIndex >= 0 && cbx_TeamAway.SelectedIndex >= 0)
            {
                if (cbx_TeamHome.SelectedIndex == cbx_TeamAway.SelectedIndex || cbx_TeamAway.SelectedIndex == cbx_TeamHome.SelectedIndex)
                {
                    MessageBox.Show("eror");
                    cbx_TeamHome.Text = string.Empty;
                    cbx_TeamAway.Text = string.Empty;
                }
                else
                {
                    //sqlConnect = new MySqlConnection("server=localhost; uid=root; password=110505*; database=premier_league");
                    dtTeam = new DataTable();
                    sqlQuery = $"SELECT team_id, team_name from team where team_name = '{cbx_TeamHome.Text}'";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeam);

                    cbx_Team.ValueMember = "team_id";
                    cbx_Team.DisplayMember = "team_name";
                    cbx_Team.DataSource = dtTeam;

                    //lb_ValueHome.Text = cbx_TeamHome.SelectedValue.ToString();
                    //MessageBox.Show("HOME " + cbx_TeamHome.SelectedValue.ToString());

                    sqlQuery = $"SELECT team_id, team_name from team where team_name = '{cbx_TeamAway.Text}'";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeam);

                    cbx_Team.ValueMember = "team_id";
                    cbx_Team.DisplayMember = "team_name";
                    cbx_Team.DataSource = dtTeam;

                    //lb_ValueAway.Text = cbx_TeamAway.SelectedValue.ToString();
                    //MessageBox.Show("AWAY " + cbx_TeamAway.SelectedValue.ToString());
                }

            }
        }

        private void cbx_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbx_TeamHome.SelectedIndex >= 0 && cbx_TeamAway.SelectedIndex >= 0)
            {
                if (cbx_TeamHome.SelectedIndex == cbx_TeamAway.SelectedIndex || cbx_TeamAway.SelectedIndex == cbx_TeamHome.SelectedIndex)
                {
                    MessageBox.Show("eror");
                    cbx_TeamHome.Text = string.Empty;
                    cbx_TeamAway.Text = string.Empty;
                }
                else
                {
                    //sqlConnect = new MySqlConnection("server=localhost; uid=root; password=110505*; database=premier_league");
                    dtTeam = new DataTable();
                    sqlQuery = $"SELECT team_id, team_name from team where team_name = '{cbx_TeamHome.Text}'";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeam);

                    cbx_Team.ValueMember = "team_id";
                    cbx_Team.DisplayMember = "team_name";
                    cbx_Team.DataSource = dtTeam;

                    //lb_ValueHome.Text = cbx_TeamHome.SelectedValue.ToString();
                    //MessageBox.Show("HOME " + cbx_TeamHome.SelectedValue.ToString());

                    sqlQuery = $"SELECT team_id, team_name from team where team_name = '{cbx_TeamAway.Text}'";
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                    sqlDataAdapter.Fill(dtTeam);

                    cbx_Team.ValueMember = "team_id";
                    cbx_Team.DisplayMember = "team_name";
                    cbx_Team.DataSource = dtTeam;

                    //lb_ValueAway.Text = cbx_TeamAway.SelectedValue.ToString();
                    //MessageBox.Show("AWAY " + cbx_TeamAway.SelectedValue.ToString());
                }
            }
        }

        private void datetime_Match_ValueChanged(object sender, EventArgs e)
        {
            var Date = new DateTime(2016, 2, 14);

            if (dateTimePicker.Value > Date)
            {
                tanggal = dateTimePicker.Value.ToString("yyyy-MM-dd");
                //MessageBox.Show(tanggal);
                //MessageBox.Show(dateTimePicker.Value.ToString());
                string tahun = dateTimePicker.Value.ToString("yyyy");

                //sqlConnect = new MySqlConnection("server=localhost; uid=root; password=110505*; database=premier_league");
                dtsimpanPremierLeague = new DataTable();
                sqlQuery = $"select left(m.match_id, 4) from `match` m where left(m.match_id, 4) = {tahun}";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtsimpanPremierLeague);

                int count = 1;
                for(int i = 0; i< dtsimpanPremierLeague.Rows.Count; i++)
                {
                    count++;
                }

                MessageBox.Show(count.ToString());
                if(count < 10)
                {
                    tb_MatchID.Text = tahun + "00" + count;
                }
                else if (count < 100)
                {
                    tb_MatchID.Text = tahun + "0" + count;
                }
                else if (count < 1000)
                {
                    tb_MatchID.Text = tahun + count;
                }                
            }
            else
            {
                MessageBox.Show("Date can't be less than 14 Feb 2016");
                tb_MatchID.Text = string.Empty;
            }
        }

        private void cbx_Team_SelectedIndexChanged(object sender, EventArgs e)
        {
            //lb_TeamPilih.Text = cbx_Team.SelectedValue.ToString();

            dtPlayer = new DataTable();
            sqlQuery = $"SELECT p.player_id, p.player_name from player p join team t on t.team_id = p.team_id where t.team_id = '{cbx_Team.SelectedValue.ToString()}'";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayer);
            cbx_Player.ValueMember = "player_id";
            cbx_Player.DisplayMember = "player_name";
            cbx_Player.DataSource = dtPlayer;

            //lb_PlayerPilih.Text = cbx_Player.SelectedValue.ToString();
        }

        private void cbx_Player_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbx_Player.ValueMember = "player_id";
            cbx_Player.DisplayMember = "player_name";
            cbx_Player.DataSource = dtPlayer;

            //lb_PlayerPilih.Text = cbx_Player.SelectedValue.ToString();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (tb_MatchID.Text.Length > 0 && cbx_TeamHome.Text.Length > 0 && cbx_TeamAway.Text.Length > 0 && tb_Minute.Text.Length > 0 && cbx_Team.Text.Length > 0 && cbx_Player.Text.Length > 0 && cbx_Type.Text.Length > 0)
            {
                dtPremierLeague.Rows.Add(cbx_Team.Text, cbx_Player.Text, cbx_Type.Text);
                dgv_premierleague.DataSource = dtPremierLeague;

                
                dtsimpanID.Rows.Add(tb_MatchID.Text, tb_Minute.Text, cbx_Team.SelectedValue, cbx_Player.SelectedValue, cbx_Type.SelectedItem,"0");
                cbx_TeamHome.Enabled = false;
                cbx_TeamAway.Enabled = false;
            }
            else
            {
                MessageBox.Show("Please fill all the column");
            }
            
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dgv_premierleague.CurrentRow;
            if(dgv_premierleague.SelectedRows.Count > 0)
            {
                dgv_premierleague.Rows.Remove(dgvr);
            }
        }

        private void btn_Insert_Click(object sender, EventArgs e)
        {
            int SkorHome = 0;
            int SkorAway = 0;
            if (dtPremierLeague.Rows.Count > 0)
            {
                for (int i = 0; i < dtPremierLeague.Rows.Count; i++)
                {
                    sqlCommand = sqlConnect.CreateCommand();
                    string sqlQueryDmatch = "INSERT INTO dmatch VALUES (@matchid, @minute, @teamid, @playerid, @type, @delete)";
                    sqlCommand.CommandText = sqlQueryDmatch;
                    sqlConnect.Open();
                    sqlCommand.Parameters.AddWithValue("@matchid", dtsimpanID.Rows[i][0].ToString());
                    sqlCommand.Parameters.AddWithValue("@minute", dtsimpanID.Rows[i][1].ToString());
                    sqlCommand.Parameters.AddWithValue("@teamid", dtsimpanID.Rows[i][2].ToString());
                    sqlCommand.Parameters.AddWithValue("@playerid", dtsimpanID.Rows[i][3].ToString());
                    sqlCommand.Parameters.AddWithValue("@type", dtsimpanID.Rows[i][4].ToString());
                    sqlCommand.Parameters.AddWithValue("@delete", dtsimpanID.Rows[i][5].ToString());
                    sqlCommand.ExecuteNonQuery();
                    sqlConnect.Close();
                }

                for (int j = 0; j < dtPremierLeague.Rows.Count; j++)
                {
                    if (dtPremierLeague.Rows[j][0].ToString() == cbx_TeamHome.Text)
                    {
                        if (dtPremierLeague.Rows[j][2].ToString() == "GO")
                        {
                            SkorHome++;
                        }
                        else if (dtPremierLeague.Rows[j][2].ToString() == "GP")
                        {
                            SkorHome++;
                        }
                        else if (dtPremierLeague.Rows[j][2].ToString() == "GW")
                        {
                            SkorAway++;
                        }
                    }
                    else if (dtPremierLeague.Rows[j][0].ToString() == cbx_TeamAway.Text)
                    {
                        if (dtPremierLeague.Rows[j][2].ToString() == "GO")
                        {
                            SkorAway++;
                        }
                        else if (dtPremierLeague.Rows[j][2].ToString() == "GP")
                        {
                            SkorAway++;
                        }
                        else if (dtPremierLeague.Rows[j][2].ToString() == "GW")
                        {
                            SkorHome++;
                        }
                    }
                }

                sqlCommand = sqlConnect.CreateCommand();
                string sqlQueryMatch = "INSERT INTO `match` VALUES(@matchid, @match_date, @team_home, @team_away, @goal_home, @goal_away, @referee_id, @delete)";
                sqlCommand.CommandText = sqlQueryMatch;
                sqlConnect.Open();
                sqlCommand.Parameters.AddWithValue("@matchid", tb_MatchID.Text);
                sqlCommand.Parameters.AddWithValue("@match_date", tanggal);
                sqlCommand.Parameters.AddWithValue("@team_home", cbx_TeamHome.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@team_away", cbx_TeamAway.SelectedValue);
                sqlCommand.Parameters.AddWithValue("@goal_home", SkorHome);
                sqlCommand.Parameters.AddWithValue("@goal_away", SkorAway);
                sqlCommand.Parameters.AddWithValue("@referee_id", "M002");
                sqlCommand.Parameters.AddWithValue("@delete", "0");
                sqlCommand.ExecuteNonQuery();
                sqlConnect.Close();

                dtPremierLeague.Rows.Clear();
                cbx_TeamHome.Enabled = true;
                cbx_TeamAway.Enabled = true;
                cbx_TeamHome.Text = String.Empty;
                cbx_TeamAway.Text = String.Empty;
            }
        }
    }
}
