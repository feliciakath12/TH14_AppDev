﻿namespace W14_Take_Home_New
{
    partial class Form_InsertMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_MatchID = new System.Windows.Forms.Label();
            this.lb_TeamHome = new System.Windows.Forms.Label();
            this.lb_MatchDate = new System.Windows.Forms.Label();
            this.lb_TeamAway = new System.Windows.Forms.Label();
            this.lb_Minute = new System.Windows.Forms.Label();
            this.lb_Team = new System.Windows.Forms.Label();
            this.lb_Player = new System.Windows.Forms.Label();
            this.lb_Type = new System.Windows.Forms.Label();
            this.dgv_premierleague = new System.Windows.Forms.DataGridView();
            this.tb_MatchID = new System.Windows.Forms.TextBox();
            this.cbx_TeamHome = new System.Windows.Forms.ComboBox();
            this.cbx_TeamAway = new System.Windows.Forms.ComboBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.tb_Minute = new System.Windows.Forms.TextBox();
            this.cbx_Team = new System.Windows.Forms.ComboBox();
            this.cbx_Player = new System.Windows.Forms.ComboBox();
            this.cbx_Type = new System.Windows.Forms.ComboBox();
            this.btn_Add = new System.Windows.Forms.Button();
            this.btn_Insert = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.lb_ValueHome = new System.Windows.Forms.Label();
            this.lb_ValueAway = new System.Windows.Forms.Label();
            this.lb_TeamPilih = new System.Windows.Forms.Label();
            this.lb_PlayerPilih = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_premierleague)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_MatchID
            // 
            this.lb_MatchID.AutoSize = true;
            this.lb_MatchID.Location = new System.Drawing.Point(46, 58);
            this.lb_MatchID.Name = "lb_MatchID";
            this.lb_MatchID.Size = new System.Drawing.Size(74, 20);
            this.lb_MatchID.TabIndex = 0;
            this.lb_MatchID.Text = "Match ID";
            // 
            // lb_TeamHome
            // 
            this.lb_TeamHome.AutoSize = true;
            this.lb_TeamHome.Location = new System.Drawing.Point(46, 111);
            this.lb_TeamHome.Name = "lb_TeamHome";
            this.lb_TeamHome.Size = new System.Drawing.Size(96, 20);
            this.lb_TeamHome.TabIndex = 1;
            this.lb_TeamHome.Text = "Team Home";
            // 
            // lb_MatchDate
            // 
            this.lb_MatchDate.AutoSize = true;
            this.lb_MatchDate.Location = new System.Drawing.Point(518, 64);
            this.lb_MatchDate.Name = "lb_MatchDate";
            this.lb_MatchDate.Size = new System.Drawing.Size(92, 20);
            this.lb_MatchDate.TabIndex = 2;
            this.lb_MatchDate.Text = "Match Date";
            // 
            // lb_TeamAway
            // 
            this.lb_TeamAway.AutoSize = true;
            this.lb_TeamAway.Location = new System.Drawing.Point(519, 111);
            this.lb_TeamAway.Name = "lb_TeamAway";
            this.lb_TeamAway.Size = new System.Drawing.Size(91, 20);
            this.lb_TeamAway.TabIndex = 3;
            this.lb_TeamAway.Text = "Team Away";
            // 
            // lb_Minute
            // 
            this.lb_Minute.AutoSize = true;
            this.lb_Minute.Location = new System.Drawing.Point(607, 224);
            this.lb_Minute.Name = "lb_Minute";
            this.lb_Minute.Size = new System.Drawing.Size(57, 20);
            this.lb_Minute.TabIndex = 4;
            this.lb_Minute.Text = "Minute";
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(607, 274);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(49, 20);
            this.lb_Team.TabIndex = 5;
            this.lb_Team.Text = "Team";
            // 
            // lb_Player
            // 
            this.lb_Player.AutoSize = true;
            this.lb_Player.Location = new System.Drawing.Point(607, 325);
            this.lb_Player.Name = "lb_Player";
            this.lb_Player.Size = new System.Drawing.Size(52, 20);
            this.lb_Player.TabIndex = 6;
            this.lb_Player.Text = "Player";
            // 
            // lb_Type
            // 
            this.lb_Type.AutoSize = true;
            this.lb_Type.Location = new System.Drawing.Point(607, 378);
            this.lb_Type.Name = "lb_Type";
            this.lb_Type.Size = new System.Drawing.Size(43, 20);
            this.lb_Type.TabIndex = 7;
            this.lb_Type.Text = "Type";
            // 
            // dgv_premierleague
            // 
            this.dgv_premierleague.AllowUserToAddRows = false;
            this.dgv_premierleague.AllowUserToDeleteRows = false;
            this.dgv_premierleague.AllowUserToResizeColumns = false;
            this.dgv_premierleague.AllowUserToResizeRows = false;
            this.dgv_premierleague.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_premierleague.Location = new System.Drawing.Point(22, 195);
            this.dgv_premierleague.Name = "dgv_premierleague";
            this.dgv_premierleague.RowHeadersWidth = 62;
            this.dgv_premierleague.RowTemplate.Height = 28;
            this.dgv_premierleague.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_premierleague.Size = new System.Drawing.Size(566, 322);
            this.dgv_premierleague.TabIndex = 8;
            // 
            // tb_MatchID
            // 
            this.tb_MatchID.Enabled = false;
            this.tb_MatchID.Location = new System.Drawing.Point(160, 52);
            this.tb_MatchID.Name = "tb_MatchID";
            this.tb_MatchID.Size = new System.Drawing.Size(166, 26);
            this.tb_MatchID.TabIndex = 9;
            // 
            // cbx_TeamHome
            // 
            this.cbx_TeamHome.FormattingEnabled = true;
            this.cbx_TeamHome.Location = new System.Drawing.Point(160, 103);
            this.cbx_TeamHome.Name = "cbx_TeamHome";
            this.cbx_TeamHome.Size = new System.Drawing.Size(166, 28);
            this.cbx_TeamHome.TabIndex = 10;
            this.cbx_TeamHome.SelectedIndexChanged += new System.EventHandler(this.cbx_TeamHome_SelectedIndexChanged);
            // 
            // cbx_TeamAway
            // 
            this.cbx_TeamAway.FormattingEnabled = true;
            this.cbx_TeamAway.Location = new System.Drawing.Point(631, 103);
            this.cbx_TeamAway.Name = "cbx_TeamAway";
            this.cbx_TeamAway.Size = new System.Drawing.Size(172, 28);
            this.cbx_TeamAway.TabIndex = 11;
            this.cbx_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cbx_TeamAway_SelectedIndexChanged);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(631, 58);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(300, 26);
            this.dateTimePicker.TabIndex = 12;
            this.dateTimePicker.ValueChanged += new System.EventHandler(this.datetime_Match_ValueChanged);
            // 
            // tb_Minute
            // 
            this.tb_Minute.Location = new System.Drawing.Point(683, 217);
            this.tb_Minute.Name = "tb_Minute";
            this.tb_Minute.Size = new System.Drawing.Size(152, 26);
            this.tb_Minute.TabIndex = 13;
            // 
            // cbx_Team
            // 
            this.cbx_Team.FormattingEnabled = true;
            this.cbx_Team.Location = new System.Drawing.Point(683, 265);
            this.cbx_Team.Name = "cbx_Team";
            this.cbx_Team.Size = new System.Drawing.Size(152, 28);
            this.cbx_Team.TabIndex = 14;
            this.cbx_Team.SelectedIndexChanged += new System.EventHandler(this.cbx_Team_SelectedIndexChanged);
            // 
            // cbx_Player
            // 
            this.cbx_Player.FormattingEnabled = true;
            this.cbx_Player.Location = new System.Drawing.Point(683, 316);
            this.cbx_Player.Name = "cbx_Player";
            this.cbx_Player.Size = new System.Drawing.Size(152, 28);
            this.cbx_Player.TabIndex = 15;
            this.cbx_Player.SelectedIndexChanged += new System.EventHandler(this.cbx_Player_SelectedIndexChanged);
            // 
            // cbx_Type
            // 
            this.cbx_Type.FormattingEnabled = true;
            this.cbx_Type.Location = new System.Drawing.Point(683, 369);
            this.cbx_Type.Name = "cbx_Type";
            this.cbx_Type.Size = new System.Drawing.Size(152, 28);
            this.cbx_Type.TabIndex = 16;
            // 
            // btn_Add
            // 
            this.btn_Add.Location = new System.Drawing.Point(611, 431);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(94, 36);
            this.btn_Add.TabIndex = 17;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = true;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // btn_Insert
            // 
            this.btn_Insert.Location = new System.Drawing.Point(468, 524);
            this.btn_Insert.Name = "btn_Insert";
            this.btn_Insert.Size = new System.Drawing.Size(118, 36);
            this.btn_Insert.TabIndex = 19;
            this.btn_Insert.Text = "Insert";
            this.btn_Insert.UseVisualStyleBackColor = true;
            this.btn_Insert.Click += new System.EventHandler(this.btn_Insert_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Location = new System.Drawing.Point(741, 431);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(94, 36);
            this.btn_Delete.TabIndex = 20;
            this.btn_Delete.Text = "Delete";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // lb_ValueHome
            // 
            this.lb_ValueHome.AutoSize = true;
            this.lb_ValueHome.Location = new System.Drawing.Point(351, 110);
            this.lb_ValueHome.Name = "lb_ValueHome";
            this.lb_ValueHome.Size = new System.Drawing.Size(51, 20);
            this.lb_ValueHome.TabIndex = 21;
            this.lb_ValueHome.Text = "label1";
            this.lb_ValueHome.Visible = false;
            // 
            // lb_ValueAway
            // 
            this.lb_ValueAway.AutoSize = true;
            this.lb_ValueAway.Location = new System.Drawing.Point(841, 111);
            this.lb_ValueAway.Name = "lb_ValueAway";
            this.lb_ValueAway.Size = new System.Drawing.Size(51, 20);
            this.lb_ValueAway.TabIndex = 22;
            this.lb_ValueAway.Text = "label1";
            this.lb_ValueAway.Visible = false;
            // 
            // lb_TeamPilih
            // 
            this.lb_TeamPilih.AutoSize = true;
            this.lb_TeamPilih.Location = new System.Drawing.Point(608, 294);
            this.lb_TeamPilih.Name = "lb_TeamPilih";
            this.lb_TeamPilih.Size = new System.Drawing.Size(51, 20);
            this.lb_TeamPilih.TabIndex = 23;
            this.lb_TeamPilih.Text = "label1";
            this.lb_TeamPilih.Visible = false;
            // 
            // lb_PlayerPilih
            // 
            this.lb_PlayerPilih.AutoSize = true;
            this.lb_PlayerPilih.Location = new System.Drawing.Point(608, 347);
            this.lb_PlayerPilih.Name = "lb_PlayerPilih";
            this.lb_PlayerPilih.Size = new System.Drawing.Size(51, 20);
            this.lb_PlayerPilih.TabIndex = 26;
            this.lb_PlayerPilih.Text = "label1";
            this.lb_PlayerPilih.Visible = false;
            // 
            // Form_InsertMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(993, 600);
            this.Controls.Add(this.lb_PlayerPilih);
            this.Controls.Add(this.lb_TeamPilih);
            this.Controls.Add(this.lb_ValueAway);
            this.Controls.Add(this.lb_ValueHome);
            this.Controls.Add(this.btn_Delete);
            this.Controls.Add(this.btn_Insert);
            this.Controls.Add(this.btn_Add);
            this.Controls.Add(this.cbx_Type);
            this.Controls.Add(this.cbx_Player);
            this.Controls.Add(this.cbx_Team);
            this.Controls.Add(this.tb_Minute);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.cbx_TeamAway);
            this.Controls.Add(this.cbx_TeamHome);
            this.Controls.Add(this.tb_MatchID);
            this.Controls.Add(this.dgv_premierleague);
            this.Controls.Add(this.lb_Type);
            this.Controls.Add(this.lb_Player);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.lb_Minute);
            this.Controls.Add(this.lb_TeamAway);
            this.Controls.Add(this.lb_MatchDate);
            this.Controls.Add(this.lb_TeamHome);
            this.Controls.Add(this.lb_MatchID);
            this.Name = "Form_InsertMatch";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form_InsertMatch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_premierleague)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_MatchID;
        private System.Windows.Forms.Label lb_TeamHome;
        private System.Windows.Forms.Label lb_MatchDate;
        private System.Windows.Forms.Label lb_TeamAway;
        private System.Windows.Forms.Label lb_Minute;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.Label lb_Player;
        private System.Windows.Forms.Label lb_Type;
        private System.Windows.Forms.DataGridView dgv_premierleague;
        private System.Windows.Forms.TextBox tb_MatchID;
        private System.Windows.Forms.ComboBox cbx_TeamHome;
        private System.Windows.Forms.ComboBox cbx_TeamAway;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.TextBox tb_Minute;
        private System.Windows.Forms.ComboBox cbx_Team;
        private System.Windows.Forms.ComboBox cbx_Player;
        private System.Windows.Forms.ComboBox cbx_Type;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.Button btn_Insert;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Label lb_ValueHome;
        private System.Windows.Forms.Label lb_ValueAway;
        private System.Windows.Forms.Label lb_TeamPilih;
        private System.Windows.Forms.Label lb_PlayerPilih;
    }
}

